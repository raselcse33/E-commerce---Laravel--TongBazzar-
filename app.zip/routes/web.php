<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', 'FrontController@index')->name('shopHome');

Route::get('/products','FrontController@products')->name('products');
// Route::get('/product/details','FrontController@productDetails')->name('product.details');
Route::get('/cheekout','FrontController@cheekOut')->name('cheekout');
Route::get('/cart','FrontController@cart')->name('cart');

Route::get('/user/login','FrontController@login')->name('user.login');

Route::post('/user/register','UserRegisterController@userRegistration')->name('user.register');
Route::post('/user/post','UserRegisterController@userLogin')->name('user.post');
Route::get('/logout','UserRegisterController@logOut')->name('logout');

// View Producrs
Route::get('/product/details/{id}','FrontController@productDetails')->name('viewProduct');

Route::get('/product/category/{id}','FrontController@productsByCategory')->name('viewCategoryProduct');
Route::get('/product/brand/{id}','FrontController@productsByBrand')->name('viewBrandProduct');

/******wish List *****/
Route::get('/add/wish/{id}','FrontController@addWishList')->name('add.wish');
Route::get('/show/wishlist','FrontController@showWishList')->name('show.wishlist');
Route::get('delete/wishlist/{id}','FrontController@deleteWishList')->name('delete.wishlist');

/****** add cart  *****/
Route::get('/cart/add/{id}','CartController@addCart')->name('add.cart');
Route::get('/cart/increment/{id}/{qty}','CartController@increment')->name('cart.increment');
Route::get('/cart/decrement/{id}/{qty}','CartController@decrement')->name('cart.decrement');
Route::get('/cart/delete/{id}','CartController@deleteCart')->name('delete.cart');
Route::get('/order-confirm', 'FrontController@orderConfirm')->name('complete');
Auth::routes();

Route::get('/admin/home', 'HomeController@index')->name('home');

Route::get('/admin/category', 'AdminController@categoryList')->name('category');
Route::post('/admin/addCategory', 'AdminController@categoryAdd')->name('addCategory');
Route::get('/admin/categoryDelete/{id}', 'AdminController@categoryDelete')->name('categoryDelete');

Route::get('/admin/brand', 'AdminController@brandList')->name('brand');
Route::post('/admin/addBrand', 'AdminController@brandAdd')->name('addBrand');
Route::get('/admin/brandDelete/{id}', 'AdminController@brandDelete')->name('brandDelete');

Route::get('/admin/product', 'AdminController@productList')->name('product');
Route::get('/admin/addProduct', 'AdminController@productAdd')->name('addProduct');
Route::post('/admin/storeProduct', 'AdminController@productStore')->name('storeProduct');
Route::get('/admin/productView/{id}', 'AdminController@productView')->name('productView');
Route::get('/admin/productEdit/{id}', 'AdminController@productEdit')->name('productEdit');
Route::get('/admin/productDelete/{id}', 'AdminController@productDelete')->name('productDelete');
Route::post('/admin/updateProduct/{id}', 'AdminController@productUpdate')->name('updateProduct');
