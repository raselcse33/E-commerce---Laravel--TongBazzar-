<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    Product Details
                    <a class="btn btn-info btn-sm float-right text-white mx-1" href="<?php echo e(route('product')); ?>">Back to Product</a>
                    <a class="btn btn-primary btn-sm float-right text-white mx-1" href="<?php echo e(route('productEdit', [$product->id])); ?>">Edit Product</a>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <p>Product Name</p>
                        </div>
                        <div class="col-md-9">
                            <p>: <?php echo e($product->productName); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <p>Product Brand</p>
                        </div>
                        <div class="col-md-9">
                            <p>: <?php echo e($product->brandName); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <p>Product Category</p>
                        </div>
                        <div class="col-md-9">
                            <p>: <?php echo e($product->categoryName); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <p>Product Description</p>
                        </div>
                        <div class="col-md-9">
                            <?php echo $product->productDescription; ?>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <p>Product Price</p>
                        </div>
                        <div class="col-md-9">
                            <p>: <?php echo e($product->productPrice); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <p>Product Display</p>
                        </div>
                        <div class="col-md-9">
                            <p>: <?php echo e($product->productDisplay == 0 ? 'General' : 'Featured'); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <p>Product Image</p>
                        </div>
                        <div class="col-md-9">
                            <img src="<?php echo e(asset($product->productImage)); ?>" class="img-fluid" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Windows\Xampp\htdocs\_Laravel\tongBazzar\resources\views/admin/product/productView.blade.php ENDPATH**/ ?>