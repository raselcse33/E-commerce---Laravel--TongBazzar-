<?php $__env->startSection('content'); ?>
hi
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sv1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Start PHP\htdocs\tongBazzar\resources\views/product.blade.php ENDPATH**/ ?>