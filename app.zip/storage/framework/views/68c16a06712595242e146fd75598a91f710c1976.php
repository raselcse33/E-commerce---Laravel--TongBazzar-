<?php $__env->startSection('content'); ?>
    <style>
        .ck-editor__editable {
            height: 200px;
        }
    </style>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    Add Product
                    <a class="btn btn-info btn-sm float-right text-white" href="<?php echo e(route('product')); ?>">Back to Product List</a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('updateProduct', $product->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="productName">Product Name</label>
                            <input name="productName" type="text" class="form-control" id="productName" placeholder="Product Name" value="<?php echo e($product->productName); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="productBrand">Product Brand</label>
                            <select name="productBrand" id="productBrand" class="form-control">
                                <option value="">Select Option</option>
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($product->brandName === $brand->brandName ? 'selected="selected"' : ''); ?> value="<?php echo e($brand->id); ?>"><?php echo e($brand->brandName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="productCategory">Product Category</label>
                            <select name="productCategory" id="productCategory" class="form-control">
                                <option value="">Select Option</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($product->categoryName === $category->categoryName ? 'selected="selected"' : ''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->categoryName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="productDescription">Product Description</label>
                            <textarea class="form-control" name="productDescription" id="productDescription" placeholder="Product Description"><?php echo $product->productDescription; ?></textarea>
                        </div>

                        <div class="form-group">
                            <img src="<?php echo e(asset($product->productImage )); ?>" alt="" class="img-fluid" style="max-width: 200px;">
                            <br>
                            <label for="productImage">Product Image</label>
                            <input type="file" class="form-control" id="productImage" name="productImage">
                        </div>

                        <div class="form-group">
                            <label for="productPrice">Product Price</label>
                            <input name="productPrice" type="text" class="form-control" id="productPrice" placeholder="Product Price" value="<?php echo e($product->productPrice); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="productDisplay">Product Display</label>
                            <select name="productDisplay" id="productDisplay" class="form-control">
                                <option <?php echo e($product->productDisplay == 1 ? 'selected="selected"' : ''); ?> value="1">Featured</option>
                                <option <?php echo e($product->productDisplay == 0 ? 'selected="selected"' : ''); ?> value="0">General</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-success float-right">Submit Product</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        ClassicEditor
            .create( document.querySelector( '#productDescription' ) )
            .catch( error => {
                console.error( error );
            } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Windows\Xampp\htdocs\_Laravel\tongBazzar\resources\views/admin/product/productEdit.blade.php ENDPATH**/ ?>