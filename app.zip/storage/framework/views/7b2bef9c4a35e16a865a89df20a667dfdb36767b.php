<?php $__env->startSection('content'); ?>
<div class="features_items"><!--features_items-->
	<h2 class="title text-center">All Items By Category</h2>
	<?php $__currentLoopData = $allProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-sm-4">
		<div class="product-image-wrapper">
			<div class="single-products">
				<div class="productinfo text-center">
					<img class="img-fluid" style="width: 208px; height: 183px" src="<?php echo e(asset($product->productImage)); ?>" alt="" />
					<h2>Tk. <?php echo e($product->productPrice); ?></h2>
					<p><?php echo e($product->productName); ?></p>
					<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
				</div>
				<div class="product-overlay">
					<div class="overlay-content">
						<h2>Tk. <?php echo e($product->productPrice); ?></h2>
						<p>Easy Polo Black Edition</p>
						<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
					</div>
				</div>
			</div>
			<div class="choose">
				<ul class="nav nav-pills nav-justified">
					<li><a href=""><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
					<li><a href="<?php echo e(route('viewProduct', $product->id)); ?>"><i class="fa fa-eye"></i>View Details</a></li>
				</ul>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


	<span class="pull-right"><?php echo e($allProduct->links()); ?></span>
</div><!--features_items-->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.sv1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Windows\Xampp\htdocs\_Laravel\tongBazzar\resources\views/pages/product_by_cat.blade.php ENDPATH**/ ?>