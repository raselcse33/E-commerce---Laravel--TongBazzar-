<?php $__env->startSection('content'); ?>

<div class="product-details"><!--product-details-->
	<div class="col-sm-5">
		<div class="view-product">
			<img src="<?php echo e(asset($getProduct->productImage)); ?>" alt="" />
		</div>
	</div>
	<div class="col-sm-7">
		<div class="product-information"><!--/product-information-->
			<h2><?php echo e($getProduct->productName); ?></h2>
			<span>
				<span>Tk. <?php echo e($getProduct->productPrice); ?></span>
				<label>Quantity:</label>
				<input type="text" value="3" />
				<button type="button" class="btn btn-fefault cart">
					<i class="fa fa-shopping-cart"></i>
					Add to cart
				</button>
			</span>
			<p><b>Brand:</b> <?php echo e($getProduct->brandName); ?></p>
			<p><b>Category:</b> <?php echo e($getProduct->categoryName); ?></p>
			<p><b>Details:</b> <?php echo $getProduct->productDescription; ?></p>
		</div><!--/product-information-->
	</div>
</div><!--/product-details-->

<div class="recommended_items"><!--recommended_items-->
	<h2 class="title text-center">Smiller items</h2>

	<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
		<div class="carousel-inner">
			<div class="item active">	
			<?php $__currentLoopData = $getSimiller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similler): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-sm-4">
					<div class="product-image-wrapper">
						<div class="single-products">
							<div class="productinfo text-center">
								<img class="img-fluid" style="width: 208px; height: 183px" src="<?php echo e(asset($similler->productImage)); ?>" alt="" />
								<h2>Tk. <?php echo e($similler->productPrice); ?></h2>
								<p><?php echo e($similler->productName); ?></p>
								<a href="" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
								<a href="<?php echo e(route('viewProduct', $similler->id)); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View Details</a>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>			
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sv1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Start PHP\htdocs\tongBazzar\resources\views/pages/product_details.blade.php ENDPATH**/ ?>