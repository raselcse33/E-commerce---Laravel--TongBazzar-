<?php $__env->startSection('content'); ?>

<section id="form"><!--form-->
	<div class="container">
		<div class="row">
			<div class="col-sm-4 col-sm-offset-1">
				<div class="login-form"><!--login form-->
					<h2>Login to your account</h2>
					<form action="<?php echo e(route('user.post')); ?>" method="post">
						<?php echo e(csrf_field()); ?>

						<input type="email" name="email" placeholder="Email Address" />
						<input type="password" name="password" placeholder="password" />
						<span>
							<input type="checkbox" class="checkbox"> 
							Keep me signed in
						</span>
						<button type="submit" class="btn btn-default">Login</button>
					</form>
				</div><!--/login form-->
			</div>
			<div class="col-sm-1">
				<h2 class="or">OR</h2>
			</div>
			<div class="col-sm-4">
				<div class="signup-form"><!--sign up form-->
					<h2>New User Signup!</h2>
					<form action="<?php echo e(route('user.register')); ?>" method="post">
						<?php echo e(csrf_field()); ?>

						<input type="text" name="name" placeholder="Name" required />
						<span class="text-danger"><strong> <?php echo e($errors->first('name')); ?></strong></span>
						<input type="email" name="email" placeholder="Email Address" required />
						<span class="text-danger"><strong> <?php echo e($errors->first('email')); ?></strong></span>
						<input type="password" name="password" placeholder="Password" required />
						<span class="text-danger"><strong> <?php echo e($errors->first('password')); ?></strong></span>
						<button type="submit" class="btn btn-default">Signup</button>
					</form>
				</div><!--/sign up form-->
			</div>
		</div>
	</div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sv2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Windows\Xampp\htdocs\_Laravel\tongBazzar\resources\views/pages/login.blade.php ENDPATH**/ ?>