<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col">
       <h3 class="text-center"> Welcome to TongBazzar</h3>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Windows\Xampp\htdocs\_Laravel\tongBazzar\resources\views/home.blade.php ENDPATH**/ ?>