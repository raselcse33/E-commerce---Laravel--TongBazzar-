@extends('layouts.app')
@section('content')
<div class="row">
    <div class="col">
       <h3 class="text-center"> Welcome to TongBazzar</h3>
    </div>
</div>
@endsection
